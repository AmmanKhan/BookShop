<?php

// Call connection file
include("connection.php");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Read the JSON file
$jsonData = file_get_contents('upload_JSON_File/code_challenge.json');

// Convert JSON data to associative array
$dataArray = json_decode($jsonData, true);

// Loop through each data item and insert into the database
foreach ($dataArray as $data) {
    $sale_id = $data['sale_id'];
    $customer_name = $data['customer_name'];
    $customer_mail = $data['customer_mail'];
    $product_id = $data['product_id'];
    $product_name = mysqli_escape_string($conn,$data['product_name']);
    $product_price = $data['product_price'];
    $sale_date = $data['sale_date'];
    $version = $data['version'];

// Prepare and execute the SQL query
    $sql = "INSERT INTO tb_sales (sale_id, customer_name, customer_mail, product_id, product_name, product_price, sale_date, version)
            VALUES ('$sale_id', '$customer_name', '$customer_mail', '$product_id', '$product_name', '$product_price', '$sale_date', '$version')";

    if ($conn->query($sql) === true) {
        echo "Record inserted successfully.<br>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();

?>