<?php require("connection.php");?>	   	
	<html>
	<head>
		<link type="text/css" rel="stylesheet" href="css/fixedHeader.dataTables.min.css">
        <link href="css/datatables.min.css" rel="stylesheet" type="text/css"> 
		<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		
                            <div class="dta_tble">
							
		
							
                               <table id="dta_tble_cndt" class="table table-striped table-bordered  compact nowrap display" style = "background: rgba(255,255,255,0.7); ">
                                    <thead>
                                        <tr>
											<!-- TABLE COLUMN HEADER -->
                                            <th>Sale ID</th>
                                            <th>Customer</th>
                                            <th>Customer Email</th>
                                            <th>Product ID</th>
											<th>Product</th>
											<th>Price</th>
											<th>Sale Date</th>
											<th>Version</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php
											/***************Query Code************/										
											$query = "Select sale_id,customer_name,customer_mail,product_id,product_name,product_price,date_format(sale_date,'%d %M, %Y'),version FROM tb_Sales";
											$result = $conn->query($query);
											if ($result->num_rows > 0) 
											{
												$price = 0;
												while($row = $result->fetch_array())
												{
												?>
													<tr role="row" class="odd">
														<td><?php echo $row[0];?></td>
														<td><?php echo $row[1];?></td>
														<td><?php echo $row[2];?></td>
														<td><?php echo $row[3];?></td>
														<td><?php echo $row[4];?></td>
														<td><?php echo $row[5]; $price = $price + $row[5]; ?></td>
														<td><?php echo $row[6];?></td>
														<td><?php echo $row[7]; if($row[7] < '1.0.17+60'){ echo "Europe/Berlin";}?></td>
													</tr>										   
											<?php	  
												}
												echo "<tr>
												<td colspan='5' style='text-align:right'> Total :</td>
												
												
													<td colspan='3'>$price</td>
													
													
												</tr>";
											}
											else
											{
												echo "0 results";
												
											}
											
											
											$conn->close();
											/***************END Query Code************/	
									?>
                                    </tbody>
                                </table>
                            </div>
                      
	</body>
	
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/datatables.min.js"></script>
	<script src="js/dataTables.fixedHeader.min.js"></script>
	<script>
		  $(document).ready(function () {
			  
			  // Setup - add a text input to each footer cell
		var cnt = 0;
		$('#dta_tble_cndt thead tr').clone(true).appendTo( '#dta_tble_cndt thead' );
		$('#dta_tble_cndt thead tr:eq(1) th').each( function (i) {
			var title = $(this).text();
			
		if(cnt == 1 || cnt == 4 ||  cnt == 5 ){
				$(this).html( '<input type="text"   />' );
		 
				$( 'input', this ).on( 'keyup change', function () {
					if ( table.column(i).search() !== this.value ) {
							table
							.column(i)
							.search( this.value )
							.draw();
					}
				});
			
			}else{
				$(this).html( '' );
			}
			cnt++;
		} );
			  
		var table =  $('#dta_tble_cndt').DataTable({
		dom: 'Brtip',
		buttons: [
		  
	   ],
		colReorder: true,
		paging: false,
		orderCellsTop: true,
		fixedHeader: true,
	});
	
		});
	</script>
</html>